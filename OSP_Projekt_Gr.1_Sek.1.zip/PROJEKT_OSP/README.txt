This project is based on:

- LabVIEW 2020 (32-bit)
- Python3 (32-bit)
- Microsoft sql server express
- Microsoft sql management studio

https://www.ni.com/pl-pl/support/downloads/software-products/download.labview.html#369643
https://www.python.org/downloads/release/python-391/
https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15
https://www.microsoft.com/en-us/download/details.aspx?id=101064


For more information check out the context help of the following VI's:
- PythonAnalyze.vi
- DATABASE.vi

